export default function CatchAll() {
  return null;
}
